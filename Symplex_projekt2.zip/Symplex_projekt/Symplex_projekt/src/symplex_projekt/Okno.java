/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package symplex_projekt;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;

/**
 *
 * @author Komar
 */
public class Okno extends JFrame implements ActionListener {

    private JButton przycisk1;
    private JButton przycisk2;
    private JButton przycisk3;
    private JButton przycisk4;
    private JButton przycisk5;
    private JLabel txt1;
    private JLabel txt2;
    private JLabel txt3;
    private JLabel txt4;
    private JLabel txt5;
    private JLabel txt6;
    private JLabel txt7;
    private JLabel txt8;
    private JLabel txt9;
    private JLabel txt10;
    private JLabel txt11;
    private JLabel txt12;
    private JLabel txt13;
    private JLabel txt14;
    private JLabel txt15;
    private JTextField tf1;
    private JTextField tf2;
    private JTextField tf3;
    private JTextField tf4;
    private JTextField tf5;
    private JTextField tf6;
    private JTextField tf7;
    private JTextField tf8;
    private JTextField tf9;
    private JTextField tf10;
    private JTextField tf11;
    private JTextArea ta1;
    private JTextArea ta2;
    private JTextArea ta3;
    private JComboBox cb1;
    private boolean czywczytac1 = true;
    private boolean czywczytac2 = true;
    private Symplex tabela;
    private Symplex tabela_final;
    private double[][] wczytana = new double[3][6];
    private double[][] wczytana_final = new double[3][6];
    private Font pogrubione;
    private Font zwykle;

    public Okno() {
        super("Symplex");
        setSize(1400, 600);
        setLocation(300, 300);
        setResizable(false);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(null);
        pogrubione = new Font("SantSerif", Font.BOLD, 18);
        zwykle = new Font("SantSerif", Font.PLAIN, 16);

        /////////////////////////////////////////////////////////
        //FUNKCJA CELU
        /////////////////////////////////////////////////////////
        txt1 = new JLabel("Funkcja celu:");
        txt1.setBounds(30, 0, 200, 20);
        txt1.setFont(pogrubione);
        add(txt1);

        txt2 = new JLabel("x_1  +  ");
        txt2.setBounds(100, 45, 100, 20);
        txt2.setFont(zwykle);
        add(txt2);

        txt3 = new JLabel("x_2  +  ");
        txt3.setBounds(250, 45, 100, 20);
        txt3.setFont(zwykle);
        add(txt3);

        txt4 = new JLabel("x_3       -->  ");
        txt4.setBounds(400, 45, 100, 20);
        txt4.setFont(zwykle);
        add(txt4);

        tf1 = new JTextField();
        tf1.setBounds(30, 30, 50, 50);
        tf1.setVisible(true);
        add(tf1);

        tf2 = new JTextField();
        tf2.setBounds(180, 30, 50, 50);
        tf2.setVisible(true);
        add(tf2);

        tf3 = new JTextField();
        tf3.setBounds(330, 30, 50, 50);
        tf3.setVisible(true);
        add(tf3);

        cb1 = new JComboBox<String>();
        cb1.setBounds(500, 45, 100, 20);
        cb1.addItem("max");
        cb1.addItem("min");
        add(cb1);
        cb1.setVisible(true);

        ///////////////////////////////////////////
        //OGRANICZENIA
        //////////////////////////////////////////
        txt5 = new JLabel("Ograniczenia:");
        txt5.setBounds(30, 100, 200, 20);
        txt5.setFont(pogrubione);
        add(txt5);

        txt7 = new JLabel("x_1  +  ");
        txt7.setBounds(100, 180, 100, 20);
        txt7.setFont(zwykle);
        add(txt7);

        txt8 = new JLabel("x_2  +  ");
        txt8.setBounds(250, 180, 100, 20);
        txt8.setFont(zwykle);
        add(txt8);

        txt9 = new JLabel("x_3       <=  ");
        txt9.setBounds(400, 180, 100, 20);
        txt9.setFont(zwykle);
        add(txt9);

        tf4 = new JTextField();
        tf4.setBounds(30, 165, 50, 50);
        tf4.setVisible(true);
        add(tf4);

        tf5 = new JTextField();
        tf5.setBounds(180, 165, 50, 50);
        tf5.setVisible(true);
        add(tf5);

        tf6 = new JTextField();
        tf6.setBounds(330, 165, 50, 50);
        tf6.setVisible(true);
        add(tf6);

        txt10 = new JLabel("x_1  +  ");
        txt10.setBounds(100, 260, 100, 20);
        txt10.setFont(zwykle);
        add(txt10);

        txt11 = new JLabel("x_2  +  ");
        txt11.setBounds(250, 260, 100, 20);
        txt11.setFont(zwykle);
        add(txt11);

        txt12 = new JLabel("x_3       <=  ");
        txt12.setBounds(400, 260, 100, 20);
        txt12.setFont(zwykle);
        add(txt12);

        tf7 = new JTextField();
        tf7.setBounds(30, 245, 50, 50);
        tf7.setVisible(true);
        add(tf7);

        tf8 = new JTextField();
        tf8.setBounds(180, 245, 50, 50);
        tf8.setVisible(true);
        add(tf8);

        tf9 = new JTextField();
        tf9.setBounds(330, 245, 50, 50);
        tf9.setVisible(true);
        add(tf9);

        tf10 = new JTextField();
        tf10.setBounds(500, 165, 50, 50);
        tf10.setVisible(true);
        add(tf10);

        tf11 = new JTextField();
        tf11.setBounds(500, 245, 50, 50);
        tf11.setVisible(true);
        add(tf11);

        txt6 = new JLabel("x_1, x_2, x_3 >= 0");
        txt6.setBounds(30, 350, 200, 20);
        txt6.setFont(zwykle);
        add(txt6);
        /////////////////////////////////////////////////
        //PRZYCISKI
        /////////////////////////////////////////////////

        przycisk1 = new JButton("Dane z zadania");
        przycisk1.setBounds(50, 450, 170, 50);
        przycisk1.addActionListener(this);
        add(przycisk1);
        przycisk2 = new JButton("Krok po kroku");
        przycisk2.setBounds(250, 450, 170, 50);
        przycisk2.addActionListener(this);
        add(przycisk2);
        przycisk3 = new JButton("Koniec");
        przycisk3.setBounds(450, 450, 170, 50);
        przycisk3.addActionListener(this);
        add(przycisk3);
        przycisk4 = new JButton("Usuń dane (od nowa)");
        przycisk4.setBounds(650, 450, 170, 50);
        przycisk4.addActionListener(this);
        add(przycisk4);
        przycisk5 = new JButton("Wyzeruj rozwiązanie");
        przycisk5.setBounds(850, 450, 170, 50);
        przycisk5.addActionListener(this);
        add(przycisk5);

        //////////////////////////////////////////////////
        //ROZWIAZANIE
        //////////////////////////////////////////////////
        txt13 = new JLabel("Tablica sympleksowa:");
        txt13.setBounds(700, 70, 200, 20);
        txt13.setFont(pogrubione);
        add(txt13);

        ta1 = new JTextArea();
        ta1.setBounds(700, 110, 430, 100);
        ta1.setVisible(true);
        add(ta1);

        txt14 = new JLabel("Wartość f. celu:");
        txt14.setBounds(1150, 50, 200, 20);
        txt14.setFont(pogrubione);
        add(txt14);

        txt15 = new JLabel("Rozwiązanie zadania:");
        txt15.setBounds(1150, 250, 200, 20);
        txt15.setFont(pogrubione);
        add(txt15);

        ta2 = new JTextArea();
        ta2.setBounds(1150, 100, 200, 100);
        ta2.setVisible(true);
        add(ta2);

        ta3 = new JTextArea();
        ta3.setBounds(1150, 300, 200, 100);
        ta3.setVisible(true);
        add(ta3);

        JTextField[] pola = {tf1,tf2,tf3,tf4,tf5,tf6,tf7,tf8,tf9,tf10,tf11};
            for(JTextField i:pola){
             i.setFont(zwykle);
            }
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source.equals(przycisk1)) {
            tf1.setText("2");
            tf2.setText("5");
            tf3.setText("4");
             tf4.setText("5");
            tf5.setText("3");
            tf6.setText("2");
             tf7.setText("1");
            tf8.setText("1");
            tf9.setText("4");
            tf10.setText("12000");
            tf11.setText("8000");
            cb1.setSelectedIndex(0);
            
        } else if (source.equals(przycisk2)) {
            if (czywczytac1){
                 wczytana[0][0] = Double.parseDouble(tf4.getText());
                 wczytana[0][1] = Double.parseDouble(tf5.getText());
                 wczytana[0][2] = Double.parseDouble(tf6.getText());
                 wczytana[1][0] = Double.parseDouble(tf7.getText());
                 wczytana[1][1] = Double.parseDouble(tf8.getText());
                 wczytana[1][2] = Double.parseDouble(tf9.getText());
                 wczytana[2][0] = Double.parseDouble(tf1.getText());
                 wczytana[2][1] = Double.parseDouble(tf2.getText());
                 wczytana[2][2] = Double.parseDouble(tf3.getText());
                 wczytana[0][5] = Double.parseDouble(tf10.getText());
                 wczytana[1][5] = Double.parseDouble(tf11.getText());
                 wczytana[2][5] = 0.0;
                 tabela = new Symplex(wczytana,2,3);
                 tabela.zmianaZnaku(cb1.getSelectedIndex()==0);
                 czywczytac1 = false;
               }
             boolean flag1 ;
             ta1.setEditable(true);
             ta1.setText("");
             ta1.setFont(zwykle);
            ta1.append("x1            x2            x3            u1            u2               cel"+"\n");
            for(int i = 0;i<=2;i++){
                String line ="";
                for(int j=0;j<=5;j++){
                    line+= String.format("%.2f",tabela.getMacierz()[i][j])+"          ";
                }
                ta1.append(line+'\n');
            }
       
            flag1 = tabela.obliczanie();
            ta1.setEditable(false);
            //flag1 = false; //TEST
             if(!flag1){
                 ta2.setEditable(true);
                 ta2.setEditable(true);
                 ta2.setText("");
                 ta3.setText("");
                 if(cb1.getSelectedIndex()==1){
                 ta2.append(Double.toString((-1)*tabela.wyswietlWartoscFunkcjiCelu()));
                 }else{
                 ta2.append(Double.toString(tabela.wyswietlWartoscFunkcjiCelu()));
                 }
                 ta3.append("Potrzeba: \n");
                 ta3.append(tabela.WyliczX()[0] + " jednostek x_1 \n");
                 ta3.append(tabela.WyliczX()[1] + " jednostek x_2 \n");
                 ta3.append(tabela.WyliczX()[2] + " jednostek x_3 \n");
                 ta2.setFont(zwykle);
                 ta3.setFont(zwykle);
                 ta2.setEditable(false);
                 ta3.setEditable(false);
                 JOptionPane.showMessageDialog(null, "Algorytm ukończony");
                 przycisk2.setEnabled(false);
                 przycisk3.setEnabled(false);
             }
            
        
            
        } else if (source.equals(przycisk3)) {
            if (czywczytac2){
                 wczytana_final[0][0] = Double.parseDouble(tf4.getText());
                 wczytana_final[0][1] = Double.parseDouble(tf5.getText());
                 wczytana_final[0][2] = Double.parseDouble(tf6.getText());
                 wczytana_final[1][0] = Double.parseDouble(tf7.getText());
                 wczytana_final[1][1] = Double.parseDouble(tf8.getText());
                 wczytana_final[1][2] = Double.parseDouble(tf9.getText());
                 wczytana_final[2][0] = Double.parseDouble(tf1.getText());
                 wczytana_final[2][1] = Double.parseDouble(tf2.getText());
                 wczytana_final[2][2] = Double.parseDouble(tf3.getText());
                 wczytana_final[0][5] = Double.parseDouble(tf10.getText());
                 wczytana_final[1][5] = Double.parseDouble(tf11.getText());
                 wczytana_final[2][5] = 0.0;
                 tabela_final = new Symplex(wczytana_final,2,3);
                 tabela_final.zmianaZnaku(cb1.getSelectedIndex()==0);
                 czywczytac2 = false;
               }
             boolean flag2=true;
             do{
             ta1.setText("");
             ta1.setFont(zwykle);
            ta1.append("x1            x2            x3            u1            u2               cel"+"\n");
            for(int i = 0;i<=2;i++){
                String line ="";
                for(int j=0;j<=5;j++){
                    line+= String.format("%.2f",tabela_final.getMacierz()[i][j])+"          ";
                }
                ta1.append(line+'\n');
            }
                 flag2 = tabela_final.obliczanie();
            //flag1 = false; //TEST
            
            
            }
             while(flag2);
        if(!flag2){
                 ta2.setEditable(true);
                 ta2.setEditable(true);
                 ta2.setText("");
                 ta3.setText("");
                 JOptionPane.showMessageDialog(null, "Algorytm ukończony");
                 przycisk2.setEnabled(false);
                 przycisk3.setEnabled(false);
                 if(cb1.getSelectedIndex()==1){
                 ta2.append(Double.toString((-1)*tabela.wyswietlWartoscFunkcjiCelu()));
                 }else{
                 ta2.append(Double.toString(tabela.wyswietlWartoscFunkcjiCelu()));
                 }
                 ta3.append("Potrzeba: \n");
                 ta3.append(tabela_final.WyliczX()[0] + " jednostek x_1 \n");
                 ta3.append(tabela_final.WyliczX()[1] + " jednostek x_2 \n");
                 ta3.append(tabela_final.WyliczX()[2] + " jednostek x_3 \n");
                 ta2.setFont(zwykle);
                 ta3.setFont(zwykle);
                 ta2.setEditable(false);
                 ta3.setEditable(false);
        } 
        } else if (source.equals(przycisk4)) {
            JTextField[] pola = {tf1,tf2,tf3,tf4,tf5,tf6,tf7,tf8,tf9,tf10,tf11};
            for(JTextField i:pola){
             i.setText("");
            }
            czywczytac1=true; //tutaj musi sie czyscic obiekt
            czywczytac2=true;
            przycisk2.setEnabled(true);
            przycisk3.setEnabled(true);
            ta1.setEditable(true);
            ta2.setEditable(true);
            ta3.setEditable(true);
            ta1.setText("");
            ta2.setText("");
            ta3.setText("");
            ta1.setEditable(false);
            ta2.setEditable(false);
            ta3.setEditable(false);
        } else if (source.equals(przycisk5)) {
            ta1.setEditable(true);
            ta2.setEditable(true);
            ta3.setEditable(true);
            ta1.setText("");
            ta2.setText("");
            ta3.setText("");
            ta1.setEditable(false);
            ta2.setEditable(false);
            ta3.setEditable(false);
        }
          
    }
}