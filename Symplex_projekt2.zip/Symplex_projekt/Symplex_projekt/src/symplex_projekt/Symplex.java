/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package symplex_projekt;

/**
 *
 * @author Komar
 */
public class Symplex {
 
 private double[][] macierz; 
 private int l_ograniczen; 
 private int l_zmiennych; 
 private boolean czymax;
 private int[] baza;
 
   public Symplex(double[][] macierz, int l_ograniczen, int l_zmiennych) {
  this.l_ograniczen=l_ograniczen;
  this.l_zmiennych = l_zmiennych;
  this.macierz = macierz;

  baza = new int[l_ograniczen];
  for (int i = 0; i < l_ograniczen; i++)
  baza[i] = l_zmiennych + i;

 }
 
  public void zmianaZnaku(boolean czymax){
      if(czymax=true){
          for(int i=0;i<this.l_zmiennych;i++){
              this.macierz[this.l_ograniczen][i] = (-1)* this.macierz[this.l_ograniczen][i];
          }
      }
  }
  
  public boolean obliczanie(){
      //wybranie kolumny
      int kolumna = 0;
      kolumna = ktoraKolumna();
     
      //if (kolumna == -1){
      //       break; //do tego dążymy - tutaj komunikat o optimum - TRY-CATCH 
      //   }
    if (kolumna ==-1){
        return false;
    }
     //wybranie wiersza
     int wiersz = ktoryWiersz(kolumna);
       if (wiersz == -1){
             System.out.println("Dzielenie przez 0");
         }
       
     //korzystam z eliminacji Gaussa-Jordana do obliczenia nowej postaci macierzy
     gaussJordan(wiersz,kolumna);
     
     this.baza[wiersz] = kolumna;
     return true;
  }
  
  
  private int ktoraKolumna(){
      int kolumna = 0;
     for (int i = 1; i < this.l_ograniczen + this.l_zmiennych; i++)
         if (macierz[this.l_ograniczen][i] < macierz[this.l_ograniczen][kolumna])
             kolumna = i;

     if (macierz[this.l_ograniczen][kolumna] >= 0){
         return -1; // optimum 
     } else {
         return kolumna;
     }
  }
  
  private int ktoryWiersz(int kolumna){
          int wiersz = -1;
     for (int i = 0; i < this.l_ograniczen; i++) {
         if (macierz[i][kolumna] <= 0)
             continue;
         else if (wiersz == -1)
             wiersz = i;
         else if ((macierz[i][this.l_ograniczen + this.l_zmiennych] / macierz[i][kolumna])
                 < (macierz[wiersz][this.l_ograniczen + this.l_zmiennych] / macierz[wiersz][kolumna]))
             wiersz = i;
     }
     return wiersz;
  }
  
  private void gaussJordan(int wiersz,int kolumna){
  
  for (int i = 0; i <= this.l_ograniczen; i++)
   for (int j = 0; j <= this.l_ograniczen + this.l_zmiennych; j++)
    if (i != wiersz && j != kolumna)
     macierz[i][j] -= macierz[wiersz][j] * macierz[i][kolumna] / macierz[wiersz][kolumna];

  for (int i = 0; i <= this.l_ograniczen; i++)
   if (i != wiersz)
    macierz[i][kolumna] = 0.0;

  for (int j = 0; j <= this.l_ograniczen + this.l_zmiennych; j++)
   if (j != kolumna)
    macierz[wiersz][j] /= macierz[wiersz][kolumna];
  macierz[wiersz][kolumna] = 1.0;
  }
  

  public double wyswietlWartoscFunkcjiCelu(){
       return this.macierz[this.l_ograniczen][this.l_ograniczen + this.l_zmiennych];
  }
 // 1. dodawać macierz z jfieldow
 // 2. baza na dopleniajacych miejscach
 // 3. funkcja LICZ, a w niej
 //    a) wyswietl tablicę najpierw tablica, z wartościami prawa strona,
 //       potem funkcja celu, potem
 //    b) q=0
 //       q = znajdz index neg
 //       if (q=-1) - OPTIMUM TRY-CATCH ERROR HANDLER
 //      znajdowanie rzedu i kolumny i piwocik
  
  
  public double[] WyliczX() {
  double[] x = new double[this.l_zmiennych];
  for (int i = 0; i < this.l_ograniczen; i++)
  if (baza[i] < this.l_zmiennych)
    x[baza[i]] = macierz[i][this.l_ograniczen + this.l_zmiennych];
  return x;
 }
  
  
  //1. Funkcja wyliczająca zmienne X 
  //2. Funkcja zwracajaca f. celu (return)

    public double[][] getMacierz() {
        return macierz;
    }

    public void setMacierz(double[][] macierz) {
        this.macierz = macierz;
    }

    public int getL_ograniczen() {
        return l_ograniczen;
    }

    public void setL_ograniczen(int l_ograniczen) {
        this.l_ograniczen = l_ograniczen;
    }

    public int getL_zmiennych() {
        return l_zmiennych;
    }

    public void setL_zmiennych(int l_zmiennych) {
        this.l_zmiennych = l_zmiennych;
    }
 
}
